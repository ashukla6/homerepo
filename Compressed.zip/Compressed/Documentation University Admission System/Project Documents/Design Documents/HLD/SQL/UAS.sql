DROP TABLE Participant cascade constraint;
DROP TABLE Users cascade constraint;
DROP TABLE ProgramsScheduled cascade constraint;
DROP TABLE Application cascade constraint;
DROP TABLE ProgramsOffered cascade constraint;
DROP SEQUENCE Application_id_seq;
DROP SEQUENCE Participant_id_seq;
DROP SEQUENCE Schedule_id_seq;

CREATE TABLE ProgramsOffered 
( programName varchar2(10) CONSTRAINT programNamePK PRIMARY KEY,
description varchar2(50),
applicantEligibility varchar2(40),duration number(3),
degreeCertificateOffered varchar2(10) );

CREATE TABLE ProgramsScheduled 
( scheduledProgramId varchar2(5) CONSTRAINT scheduledProgramIdPK PRIMARY KEY,
programName varchar2(10) CONSTRAINT programNameFK REFERENCES ProgramsOffered(programName),
location varchar2(10), startDate date,
endDate date, sessionsPerWeek number(2) );

CREATE TABLE Application
( applicationId number(6) CONSTRAINT applicationIdPK PRIMARY KEY,
fullName varchar2(20),
dateOfBirth date, highestQualification varchar2(10),
marksObtained number(3), goals varchar2(20), 
emailId varchar2(20) UNIQUE , scheduledProgramId varchar2(5)  CONSTRAINT scheduledIdFK REFERENCES ProgramsScheduled(scheduledProgramId), 
status varchar2(10) , dateOfInterview date );

CREATE TABLE Participant 
( rollNo varchar2(8)  CONSTRAINT rollNoPK PRIMARY KEY,
emailId varchar2(20) CONSTRAINT emailIdFK REFERENCES Application(emailId),
applicationId number(6) CONSTRAINT applicationIdFK REFERENCES Application(applicationId), 
scheduledProgramId varchar2(5) CONSTRAINT scheduledProgramIdFK REFERENCES ProgramsScheduled(scheduledProgramId));

CREATE TABLE Users 
( loginId varchar2(5), password varchar2(10), role varchar2(5) );

CREATE sequence Application_id_seq start with 100000;
CREATE sequence Participant_id_seq start with 10000;
CREATE sequence Schedule_id_seq start with 1000;

INSERT INTO Users values('mac','pass','mac');
INSERT INTO Users values('admin','pass','admin');
INSERT INTO Users values('teja','sai','mac');

commit;

